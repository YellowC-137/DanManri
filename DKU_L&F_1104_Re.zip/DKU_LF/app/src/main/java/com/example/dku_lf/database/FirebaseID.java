package com.example.dku_lf.database;

public class FirebaseID {

    public static String user = "user";

    public static String post = "post";

    public static String documentId = "documentID";
    public static String email = "email";
    public static String password = "password";

    public static String title = "title";
    public static String contents = "contents";
    public static String timestamp = "timestamp";
}
